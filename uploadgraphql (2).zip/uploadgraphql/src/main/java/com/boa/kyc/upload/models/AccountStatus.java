package com.boa.kyc.upload.models;

public enum AccountStatus {
   ACTIVE,FRAUD,BLOCKED,CLOSED,NPA
}
